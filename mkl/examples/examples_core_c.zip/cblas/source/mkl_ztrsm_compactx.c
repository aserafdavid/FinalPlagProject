/*******************************************************************************
* Copyright 1999-2017 Intel Corporation All Rights Reserved.
*
* The source code,  information  and material  ("Material") contained  herein is
* owned by Intel Corporation or its  suppliers or licensors,  and  title to such
* Material remains with Intel  Corporation or its  suppliers or  licensors.  The
* Material  contains  proprietary  information  of  Intel or  its suppliers  and
* licensors.  The Material is protected by  worldwide copyright  laws and treaty
* provisions.  No part  of  the  Material   may  be  used,  copied,  reproduced,
* modified, published,  uploaded, posted, transmitted,  distributed or disclosed
* in any way without Intel's prior express written permission.  No license under
* any patent,  copyright or other  intellectual property rights  in the Material
* is granted to  or  conferred  upon  you,  either   expressly,  by implication,
* inducement,  estoppel  or  otherwise.  Any  license   under such  intellectual
* property rights must be express and approved by Intel in writing.
*
* Unless otherwise agreed by Intel in writing,  you may not remove or alter this
* notice or  any  other  notice   embedded  in  Materials  by  Intel  or Intel's
* suppliers or licensors in any way.
*******************************************************************************/

/*
!  Content:
!      M K L _ Z R T S M _ C O M P A C T  Example Program Text ( C Interface )
!******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "mkl.h"

#include "mkl_example.h"

#define MEM_ALIGNMENT 64
#define MAX_NM 512

int main(int argc, char *argv[])
{

  FILE *in_file;
  char *in_file_name;

  MKL_INT i, j, p_num, idx_matrix;
  MKL_INT m, n, k, nm;
  MKL_INT lda, ldap, ldb, ldbp;
  MKL_INT sda, sdap, sdb, sdbp;
  MKL_INT a_idx, b_idx, adim;
  MKL_INT a_total, b_total;
  MKL_Complex16 *a, *b;
  MKL_Complex16 *a_array[MAX_NM], *b_array[MAX_NM];
  double *a_compact, *b_compact;
  MKL_INT a_buffer, b_buffer;
  MKL_SIDE SIDE;
  MKL_UPLO UPLO;
  MKL_DIAG DIAG;
  MKL_TRANSPOSE TRANSA;
  MKL_LAYOUT layout;
  MKL_COMPACT_PACK COMPACT_FORMAT;
  MKL_Complex16 alpha;

  printf("\n     M K L _ Z T R S M _ C O M P A C T  EXAMPLE PROGRAM\n");

/*       Get input data                                        */

  if( argc == 1 ) {
    printf("\n You must specify in_file data file as 1-st parameter");
    return 1;
  }
  in_file_name = argv[1];

  if( (in_file = fopen( in_file_name, "r" )) == NULL ) {
     printf("\n ERROR on OPEN '%s' with mode=\"r\"\n", in_file_name);
     return 1;
  }
  if( GetIntegerParameters(in_file, &m, &n, &nm) != 3 ) {
      printf("\n ERROR of m, n, k reading\n");
      return 1;
  }
  if( GetScalarsZ(in_file, &alpha) != 1 ) {
      printf("\n ERROR of alpha, beta reading\n");
      return 1;
  }
  if( GetCblasCharParameters(in_file, &SIDE, &UPLO, &TRANSA, &DIAG, &layout) !=5 ) {
    printf("\n ERROR of SIDE, UPLO, TRANSA, DIAG, layout reading\n");
    return 1;
  }

  if ( SIDE == MKL_LEFT ) {
    adim = m;
  } else {
    adim = n;
  }
  lda = adim;
  sda = adim;
  ldap = adim;
  sdap = adim;

  if ( layout == MKL_COL_MAJOR ) {
    ldb = m;
    sdb = n;
    ldbp = m;
    sdbp = n;
  } else {
    ldb = n;
    sdb = m;
    ldbp = n;
    sdbp = m;
  }

/*	Set up standard arrays in P2P format			*/
  a_total = adim * adim * nm;
  b_total = m * n * nm;
  a = (MKL_Complex16 *)mkl_malloc( a_total * sizeof(MKL_Complex16), MEM_ALIGNMENT );
  b = (MKL_Complex16 *)mkl_malloc( b_total * sizeof(MKL_Complex16), MEM_ALIGNMENT );

  for (i = 0; i < a_total; i++) a[i].real = rand() / (double) RAND_MAX + .5;
  for (i = 0; i < a_total; i++) a[i].imag = rand() / (double) RAND_MAX + .5;
  for (i = 0; i < b_total; i++) b[i].real = rand() / (double) RAND_MAX + .5;
  for (i = 0; i < b_total; i++) b[i].imag = rand() / (double) RAND_MAX + .5;

  a_idx = 0;
  b_idx = 0;
  p_num = 0;
  for (j = 0; j < nm; j++) {
    a_array[p_num] = &a[ a_idx ];
    b_array[p_num] = &b[ b_idx ];
    p_num++;
    a_idx += adim * lda;
    b_idx += (layout == MKL_COL_MAJOR) ? (ldb * n) : (ldb * m);
  }
  idx_matrix = 0;
  for (j = 0; j < nm; j++) {
    for (i = 0; i < adim; i++) {
      a_array[idx_matrix][i*lda + i].real = 10.0;
    }
    idx_matrix++;
  }

/*       Print input data                                      */

  printf("\n     INPUT DATA");
  printf("\n       M="INT_FORMAT"  N="INT_FORMAT"  NM="INT_FORMAT, m, n, nm);
  printf("\n       ALPHA=%5.1f", alpha);
  PrintParameters("SIDE, UPLO, TRANSA, DIAG", SIDE, UPLO, TRANSA, DIAG);
  PrintParameters("LAYOUT", layout);
  for (i = 0; i < nm; i++) {
    printf("\nMatrix set %d:", i);
    PrintArrayS(&layout, FULLPRINT, GENERAL_MATRIX, &adim, &adim, a_array[i], &lda, "A");
    PrintArrayS(&layout, FULLPRINT, GENERAL_MATRIX, &m, &n, b_array[i], &ldb, "B");
  }

/*	Set up Compact arrays					*/
  COMPACT_FORMAT = mkl_get_format_compact();

  a_buffer = mkl_cget_size_compact( ldap, sdap, COMPACT_FORMAT, nm );
  b_buffer = mkl_cget_size_compact( ldbp, sdbp, COMPACT_FORMAT, nm );

  a_compact = (double *)mkl_malloc( a_buffer, MEM_ALIGNMENT );
  b_compact = (double *)mkl_malloc( b_buffer, MEM_ALIGNMENT );

/*	Pack from P2P to Compact format				*/
  mkl_cgepack_compact( layout, adim, adim, a_array, lda, a_compact, ldap, COMPACT_FORMAT, nm );
  mkl_cgepack_compact( layout, m, n, b_array, ldb, b_compact, ldbp, COMPACT_FORMAT, nm );

/*	Perform Compact GEMM					*/
  mkl_ctrsm_compact( layout, SIDE, UPLO, TRANSA, DIAG, m, n, &alpha, a_compact, ldap, b_compact, ldbp, COMPACT_FORMAT, nm );

/*	Unpack from Compact to P2P format			*/
  mkl_cgeunpack_compact( layout, m, n, b_array, ldb, b_compact, ldbp, COMPACT_FORMAT, nm );

/*       Print output data                                     */
  printf("\n\n     OUTPUT DATA");
  for (i = 0; i < nm; i++) {
    printf("\nMatrix set %d:", i);
    PrintArrayZ(&layout, FULLPRINT, GENERAL_MATRIX, &m,  &n,  b_array[i], &ldb, "B");
  }

  mkl_free(a_compact);
  mkl_free(b_compact);
  mkl_free(a);
  mkl_free(b);

  return 0;
}
