/*******************************************************************************
* Copyright 2011-2017 Intel Corporation All Rights Reserved.
*
* The source code,  information  and material  ("Material") contained  herein is
* owned by Intel Corporation or its  suppliers or licensors,  and  title to such
* Material remains with Intel  Corporation or its  suppliers or  licensors.  The
* Material  contains  proprietary  information  of  Intel or  its suppliers  and
* licensors.  The Material is protected by  worldwide copyright  laws and treaty
* provisions.  No part  of  the  Material   may  be  used,  copied,  reproduced,
* modified, published,  uploaded, posted, transmitted,  distributed or disclosed
* in any way without Intel's prior express written permission.  No license under
* any patent,  copyright or other  intellectual property rights  in the Material
* is granted to  or  conferred  upon  you,  either   expressly,  by implication,
* inducement,  estoppel  or  otherwise.  Any  license   under such  intellectual
* property rights must be express and approved by Intel in writing.
*
* Unless otherwise agreed by Intel in writing,  you may not remove or alter this
* notice or  any  other  notice   embedded  in  Materials  by  Intel  or Intel's
* suppliers or licensors in any way.
*******************************************************************************/

/*
! Content:
!       Example of using fftwf_plan_many_dft_c2r function.
!
!****************************************************************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <float.h>
#include "fftw3.h"

static void init_c(fftwf_complex *x,
                   int *N, int M, int *EN, int stride, int dist, int *H);
static int verify_r(float *x,
                    int *N, int M, int *EN, int stride, int dist, int *H);

int main(void)
{
    /*
     * In this example we perform M in-place 3D FFT on the data
     * contained in a larger array.  The sizes of the FFT are defined
     * by array N[], the embedding array has dimensions defined by
     * array EN[] and EM, not necessarily in this order.
     */

    /* Sizes of 3D transform and the number of them */
    int N[3] = { 12, 24, 6 };
    int M = 16;

    /* Sizes of embedding real array, stride and distance, to be defined */
    int EN[3], EM, stride, dist;

    /* Stride and distance for the multiple transform, to be defined */

    /* Arbitrary harmonic used to verify FFT */
    int H[3] = { 2, 3, 5 };

    /* FFTW plan handle */
    fftwf_plan c2r = 0;

    /* Pointer to input/output data */
    fftwf_complex *x = 0;

    /* Execution status */
    int status = 0;

    printf("Example sp_plan_many_dft_c2r\n");
    printf("Multiple 3D c2r in-place FFTs\n");
    printf("Configuration parameters:\n");
    printf(" N  = {%d, %d, %d}\n", N[0], N[1], N[2]);
    printf(" M  = %d\n", M);
    printf(" H  = {%d, %d, %d}\n", H[0], H[1], H[2]);

    printf("Define data layout for complex domain\n");
    /*
     * Leading dimension is N[2], embedding array
     * has dimensions (EM,EN[0],EN[1],EN[2]).
     */
    stride = 1;
    EN[2]  = (N[2]/2+1)*stride  +1;   /* +1 is arbitrary padding */
    EN[1]  =  N[1]              +2;   /* +2 is arbitrary padding */
    EN[0]  =  N[0]              +3;   /* +3 is arbitrary padding */
    dist   =  EN[0]*EN[1]*EN[2] +4;   /* +4 is arbitrary padding */
    EM     = M;
    printf(" EM=%i, dist=%i, EN={%i,%i,%i}, stride=%i\n",
           EM,dist,EN[0],EN[1],EN[2],stride);

    printf("Allocate complex x(%i)\n", EM*dist );
    x  = fftwf_malloc(sizeof(fftwf_complex) * EM*dist );
    if (0 == x) goto failed;

    printf("Create FFTW plan for c2r transform\n");
    {
        int ENr[3];
        ENr[0] = EN[0];
        ENr[1] = EN[1];
        ENr[2] = EN[2] * 2;
        c2r = fftwf_plan_many_dft_c2r(3, N, M,
                                     x, EN, stride, dist,
                                     (float*)x, ENr, stride, dist*2,
                                     FFTW_ESTIMATE);
        if (0 == c2r) goto failed;
    }

    printf("Initialize input for c2r transform\n");
    init_c(x, N, M, EN, stride, dist, H);

    printf("Compute c2r FFT\n");
    fftwf_execute(c2r);

    printf("Verify the result of c2r FFT\n");
    status = verify_r((float*)x, N, M, EN, stride, dist*2, H);
    if (0 != status) goto failed;

 cleanup:

    printf("Destroy FFTW plan\n");
    fftwf_destroy_plan(c2r);

    printf("Free data array\n");
    fftwf_free(x);

    printf("TEST %s\n",0==status ? "PASSED" : "FAILED");
    return status;

 failed:
    printf(" ERROR\n");
    status = 1;
    goto cleanup;
}

/* Compute (K*L)%M accurately */
static float moda(int K, int L, int M)
{
    return (float)(((long long)K * L) % M);
}

/* Initialize arrays x with harmonic H */
static void init_c(fftwf_complex *x,
                   int *N, int M, int *EN, int stride, int dist, int *H)
{
    float TWOPI = 6.2831853071795864769f, phase;
    int n1, n2, n3, m, S1, S2, S3, index;

    S3 = stride;
    S2 = EN[2];
    S1 = EN[1]*S2;

    for (m = 0; m < M; m++)
    {
        for (n1 = 0; n1 < N[0]; n1++)
        {
            for (n2 = 0; n2 < N[1]; n2++)
            {
                for (n3 = 0; n3 < N[2]/2+1; n3++)
                {
                    phase  = moda(n1,H[0],N[0]) / N[0];
                    phase += moda(n2,H[1],N[1]) / N[1];
                    phase += moda(n3,H[2],N[2]) / N[2];
                    index = n1*S1 + n2*S2 + n3*S3 + m*dist;
                    x[index][0] =  cosf( TWOPI * phase ) / (N[0]*N[1]*N[2]);
                    x[index][1] = -sinf( TWOPI * phase ) / (N[0]*N[1]*N[2]);
                }
            }
        }
    }
}

/* Verify that x has unit peak at H */
static int verify_r(float *x,
                  int *N, int M, int *EN, int stride, int dist, int *H)
{
    float err, errthr, maxerr;
    int n1, n2, n3, m, S1, S2, S3, index;

    S3 = stride;
    S2 = EN[2]*2;
    S1 = EN[1]*S2;

    /*
     * Note, this simple error bound doesn't take into account error of
     * input data
     */
    errthr = 2.5f * logf( (float)N[0]*N[1]*N[2] ) / logf(2.0f) * FLT_EPSILON;
    printf(" Check if err is below errthr %.3g\n", errthr);

    maxerr = 0;
    for (m = 0; m < M; m++)
    {
        for (n1 = 0; n1 < N[0]; n1++)
        {
            for (n2 = 0; n2 < N[1]; n2++)
            {
                for (n3 = 0; n3 < N[2]; n3++)
                {
                    float re_exp = 0.0, re_got;

                    if ((n1-H[0])%N[0]==0 &&
                        (n2-H[1])%N[1]==0 &&
                        (n3-H[2])%N[2]==0)
                    {
                        re_exp = 1;
                    }

                    index = n1*S1 + n2*S2 + n3*S3 + m*dist;
                    re_got = x[index];
                    err  = fabsf(re_got - re_exp);
                    if (err > maxerr) maxerr = err;
                    if (!(err < errthr))
                    {
                        printf(" x(n1=%i,n2=%i,n3=%i,m=%i): ",n1,n2,n3,m);
                        printf(" expected %.7g, ",re_exp);
                        printf(" got %.7g, ",re_got);
                        printf(" err %.3g\n", err);
                        printf(" Verification FAILED\n");
                        return 1;
                    }
                }
            }
        }
    }
    printf(" Verified,  maximum error was %.3g\n", maxerr);
    return 0;
}
