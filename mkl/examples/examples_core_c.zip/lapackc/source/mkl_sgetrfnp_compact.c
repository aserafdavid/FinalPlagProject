/*******************************************************************************
* Copyright 2017 Intel Corporation All Rights Reserved.
*
* The source code,  information  and material  ("Material") contained  herein is
* owned by Intel Corporation or its  suppliers or licensors,  and  title to such
* Material remains with Intel  Corporation or its  suppliers or  licensors.  The
* Material  contains  proprietary  information  of  Intel or  its suppliers  and
* licensors.  The Material is protected by  worldwide copyright  laws and treaty
* provisions.  No part  of  the  Material   may  be  used,  copied,  reproduced,
* modified, published,  uploaded, posted, transmitted,  distributed or disclosed
* in any way without Intel's prior express written permission.  No license under
* any patent,  copyright or other  intellectual property rights  in the Material
* is granted to  or  conferred  upon  you,  either   expressly,  by implication,
* inducement,  estoppel  or  otherwise.  Any  license   under such  intellectual
* property rights must be express and approved by Intel in writing.
*
* Unless otherwise agreed by Intel in writing,  you may not remove or alter this
* notice or  any  other  notice   embedded  in  Materials  by  Intel  or Intel's
* suppliers or licensors in any way.
*******************************************************************************/

/*
   MKL_SGETRFNP_COMPACT Example.
   ==============

   Program computes the LU factorization, without pivoting, of a set of matrices
   A1, ... , Anmat using compact routines. 
   For this example, nmat = 512; however, only the results and input for the
   first matrix A1 are shown.

   Description.
   ============

   The routine computes the LU factorization, without pivoting, of a set of
   general, m x n matrices, that have been stored in compact format. 
*/
#include <stdio.h>
#include <stdlib.h>
#include "mkl.h"

#define LAYOUT    MKL_COL_MAJOR
#define M                     5
#define N                     4
#define NMAT                512

/* Auxiliary routines prototypes */
extern void print_matrix(MKL_LAYOUT layout, MKL_INT m, MKL_INT n, float* a,
                         MKL_INT lda);

int main() {
    MKL_INT i, j;

    MKL_LAYOUT layout = LAYOUT;
    MKL_INT col_major = (layout == MKL_COL_MAJOR);
    MKL_INT m = M;
    MKL_INT n = N;
    MKL_INT lda = col_major ? m : n;
    MKL_INT info;
    MKL_COMPACT_PACK format;
    MKL_INT nmat = NMAT;

    /* For setting up compact arrays */
    MKL_INT a_buffer_size;
    MKL_INT ldap = lda;
    MKL_INT sdap = (col_major ? n : m);
    MKL_INT a_size = lda * (col_major ? n : m);

    /* Set up standard arrays in P2P (pointer-to-pointer) format */
    MKL_INT na = lda * (col_major ? n : m) * nmat;
    float *a = (float *)mkl_malloc(na * nmat * sizeof(float), 128);
    float *a_array[NMAT];

    float *a_compact;

    /* For random generation of matrices */
    MKL_INT idist = 1;
    MKL_INT iseed[] = { 0, 1, 2, 3 };
    float diag_offset = (float)m;

    /* Random generation of matrices */
    slarnv(&idist, iseed, &na, a);

    for (i = 0; i < nmat; i++) {
        /* Make matrix diagonal dominant to avoid accuracy issues
                 in the non-pivoted LU factorization */
        for (j = 0; j < n; j++) {
            a[i * a_size + j + j * lda] += diag_offset;
        }
        a_array[i] = &a[i * a_size];
    }

    /* Print input data */
    printf("   LAYOUT=%s, M=%d, N=%d, NMAT=%d\n",
            (col_major ? "COL-MAJOR" : "ROW-MAJOR"), m, n, nmat);
    printf("\n   Matrix A1:\n");
    print_matrix(layout, m, n, a_array[0], lda);

    /* Set up Compact arrays */
    format = mkl_get_format_compact();

    a_buffer_size = mkl_sget_size_compact(ldap, sdap, format, nmat);

    a_compact = (float *)mkl_malloc(a_buffer_size, 128);

    /* Pack from P2P to Compact format */
    mkl_sgepack_compact(layout, m, n, a_array, lda, a_compact, ldap, format, nmat);

    /* Perform Compact LU Factorization */
    mkl_sgetrfnp_compact(layout, m, n, a_compact, ldap, &info, format, nmat);

    /* Unpack from Compact to P2P format */
    mkl_sgeunpack_compact(layout, m, n, a_array, lda, a_compact, ldap, format, nmat);

    /* Print output data */
    printf("\n\n   Matrix A1 after factorization:\n");
    print_matrix(layout, m, n, a_array[0], lda);

    mkl_free(a_compact);
    mkl_free(a);

    return 0;
}

/* Auxiliary routine: printing a matrix */
void print_matrix(MKL_LAYOUT layout, MKL_INT m, MKL_INT n, float* a, MKL_INT lda) {
    MKL_INT i, j;
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            if (layout == MKL_COL_MAJOR) {
                printf(" %6.2f", a[i + j * lda]);
            } else {
                printf(" %6.2f", a[j + i * lda]);
            }
        }
        printf("\n");
    }
}
